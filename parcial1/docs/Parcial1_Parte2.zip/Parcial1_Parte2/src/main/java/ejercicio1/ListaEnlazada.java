package ejercicio1;

public class ListaEnlazada {

    private Nodo cabeza;

    public void agregarFinal(int dato) {
        Nodo nuevo = new Nodo(dato);
        if (cabeza == null) {
            cabeza = nuevo;
            return;
        }
        Nodo actual = cabeza;
        while (actual.siguiente != null) {
            actual = actual.siguiente;
        }
        actual.siguiente = nuevo;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("[");
        Nodo a = cabeza;
        while (a != null) {
            sb.append(a.dato);
            if (a.siguiente != null) sb.append(", ");
            a = a.siguiente;
        }
        return sb.append("]").toString();
    }

    // ====== A IMPLEMENTAR ======
    public void eliminarDuplicadosConsecutivos() {
        // TODO
    }
}
